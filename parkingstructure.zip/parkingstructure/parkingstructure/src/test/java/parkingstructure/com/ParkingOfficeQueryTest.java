package parkingstructure.com;

import org.junit.jupiter.api.Test;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

class ParkingOfficeQueryTests {

    @Test
    void testGetCustomerIds() {
        Address addr = new Address("100 Office Way", "", "Magna", "UT", "84044");
        ParkingOffice office = new ParkingOffice("Office", addr);

        Customer c1 = office.register("Carl", addr, "801-555-1212");
        Customer c2 = office.register("Alice", addr, "801-555-9999");

        Collection<String> ids = office.getCustomerIds();

        assertEquals(2, ids.size());
        assertTrue(ids.contains(c1.getCustomerId()));
        assertTrue(ids.contains(c2.getCustomerId()));
    }

    @Test
    void testGetPermitIds() {
        Address addr = new Address("100 Office Way", "", "Magna", "UT", "84044");
        ParkingOffice office = new ParkingOffice("Office", addr);

        Customer c = office.register("Carl", addr, "801-555-1212");
        Car car1 = office.register(c, "AAA111", CarType.SUV);
        Car car2 = office.register(c, "BBB222", CarType.COMPACT);

        Collection<String> permits = office.getPermitIds();

        assertEquals(2, permits.size());
        assertTrue(permits.contains(car1.getPermit()));
        assertTrue(permits.contains(car2.getPermit()));
    }

    @Test
    void testGetPermitIdsForCustomer() {
        Address addr = new Address("100 Office Way", "", "Magna", "UT", "84044");
        ParkingOffice office = new ParkingOffice("Office", addr);

        Customer c1 = office.register("Carl", addr, "801-555-1212");
        Customer c2 = office.register("Alice", addr, "801-555-9999");

        Car car1 = office.register(c1, "AAA111", CarType.SUV);
        Car car2 = office.register(c1, "BBB222", CarType.COMPACT);
        office.register(c2, "CCC333", CarType.SUV);

        Collection<String> carlsPermits = office.getPermitIds(c1);

        assertEquals(2, carlsPermits.size());
        assertTrue(carlsPermits.contains(car1.getPermit()));
        assertTrue(carlsPermits.contains(car2.getPermit()));
    }
}
