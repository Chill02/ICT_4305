package parkingstructure.com;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EqualityTests {

    @Test
    void testCustomerEquality() {
        Address a = new Address("123", "", "Magna", "UT", "84044");
        Customer c1 = new Customer("Carl", a, "801");
        Customer c2 = new Customer("Carl", a, "801");

        assertNotEquals(c1, c2); // different UUIDs
        assertEquals(c1, c1);
    }

    @Test
    void testCarEquality() {
        Car c1 = new Car("PERMIT-123", null, "AAA", CarType.SUV, "1");
        Car c2 = new Car("PERMIT-123", null, "BBB", CarType.COMPACT, "2");

        assertEquals(c1, c2); // same permit
    }

    @Test
    void testParkingLotEquality() {
        Address a = new Address("123", "", "Magna", "UT", "84044");
        ParkingOffice office = new ParkingOffice("Office", a);

        ParkingLot l1 = new ParkingLot("LOT-1", a, 10, office);
        ParkingLot l2 = new ParkingLot("LOT-1", a, 20, office);

        assertEquals(l1, l2);
    }

    @Test
    void testParkingChargeEquality() {
        Money m = new Money(500);
        ParkingCharge p1 = new ParkingCharge("PERMIT-1", "LOT-1", java.time.Instant.now(), m);
        ParkingCharge p2 = new ParkingCharge("PERMIT-1", "LOT-1", p1.getIncurred(), m);

        assertEquals(p1, p2);
    }
}

